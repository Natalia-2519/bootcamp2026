Proyecto modulo 3
La aplicacion es una calculadora que se ejecuta en la consola del navegador
y muestra los contenidos de esta leccion.

1. Clonar o descargar esta carpeta.
2. Abrir el archivo `index.html` en un navegador.
3. Presionar **F12** y seleccionar la pestaña **Console / Consola**.
4. Recargar la página (**Ctrl + R**).
5. Seguir las instrucciones que aparecen en los `prompt` del navegador.

su principal interaccion es nediante ventanas "prompt" y mensajes en la consola.

funcion:
- Sumar, restar, multiplicar y dividir dos números ingresados por el usuario.
- Validar que las entradas sean numéricas y evitar la división por cero.
- Guardar cada operación en un **historial**.
- Mostrar el historial completo en la consola.
- Filtrar operaciones por resultado mínimo.
- Mostrar un historial avanzado utilizando un objeto con métodos, `map` y `forEach`


Durante el desarrollo cometí varios errores con prompt y con la consola, pero eso me sirvió para aprender a usar mejor Visual Studio Code y las DevTools del navegador.

Me gustaría seguir mejorando esta calculadora agregando más operaciones y una versión con interfaz gráfica en el futuro.