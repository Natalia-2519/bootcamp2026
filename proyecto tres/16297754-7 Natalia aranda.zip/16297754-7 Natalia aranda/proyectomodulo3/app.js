// ===== PROYECTO MÓDULO 3 - APLICACIÓN DE CONSOLA =====


// LECCIÓN 1: Mensajes en consola, prompt y alert
console.log("=== CALCULADORA ABP - MÓDULO 3 ===");
let nombreUsuario = prompt("Ingresa tu nombre:");
alert("¡Hola " + nombreUsuario + "! Bienvenido/a a la calculadora ABP.");

// ARREGLO GLOBAL DE OBJETOS PARA EL HISTORIAL 
let historialOperaciones = [];

// LECCIÓN 2: Variables, operadores y condicionales
// Función para validar que el usuario ingrese un número
function obtenerNumero(mensaje) {
    let numero;
    do {
        let entrada = prompt(mensaje);
        numero = parseFloat(entrada);
        if (isNaN(numero)) {
            alert("Error: Debes ingresar un número válido.");
        }
    } while (isNaN(numero));
    return numero;
}

// Funciones para cada operación matemática
function sumar(a, b) {
    return a + b;
}

function restar(a, b) {
    return a - b;
}

function multiplicar(a, b) {
    return a * b;
}

function dividir(a, b) {
    if (b === 0) {
        alert("Error: No se puede dividir por 0.");
        return null;
    }
    return a / b;
}

// Función que ejecuta la operación elegida y guarda en historial (usa funciones dentro de funciones)
function ejecutarOperacion(tipo) {
    let num1 = obtenerNumero("Ingresa el primer número:");
    let num2 = obtenerNumero("Ingresa el segundo número:");
    let resultado;

    switch (tipo) {  // Uso de switch (Lección 2)
        case "suma":
            resultado = sumar(num1, num2);
            break;
        case "resta":
            resultado = restar(num1, num2);
            break;
        case "multiplicacion":
            resultado = multiplicar(num1, num2);
            break;
        case "division":
            resultado = dividir(num1, num2);
            break;
        default:
            alert("Tipo de operación no válida.");
            return;
    }

    if (resultado !== null) { // if para controlar división por 0
        alert("Resultado: " + resultado);

        // Guardar en arreglo de objetos 
        let operacion = {
            tipo: tipo,
            numero1: num1,
            numero2: num2,
            resultado: resultado,
            fecha: new Date().toLocaleString()
        };
        historialOperaciones.push(operacion);
    }
}

// LECCIÓN 3: Recorrer arreglos con for y while, y filtrar
function mostrarHistorial() {
    if (historialOperaciones.length === 0) {
        console.log("No hay operaciones en el historial.");
        alert("No hay operaciones en el historial.");
        return;
    }

    console.log("=== HISTORIAL COMPLETO (for) ===");
    for (let i = 0; i < historialOperaciones.length; i++) {
        let op = historialOperaciones[i];
        console.log(
            (i + 1) + ". " +
            op.tipo + " -> " +
            op.numero1 + " y " + op.numero2 +
            " = " + op.resultado +
            " (" + op.fecha + ")"
        );
    }
}

// Función que filtra operaciones según un mínimo de resultado (filtro + while)
function filtrarHistorialPorResultadoMinimo() {
    if (historialOperaciones.length === 0) {
        alert("No hay historial para filtrar.");
        return;
    }

    let minimo = obtenerNumero("Mostrar operaciones con resultado MAYOR O IGUAL a:");
    let filtradas = [];

    // filtramos con for
    for (let i = 0; i < historialOperaciones.length; i++) {
        if (historialOperaciones[i].resultado >= minimo) {
            filtradas.push(historialOperaciones[i]);
        }
    }

    console.log("=== HISTORIAL FILTRADO (while) ===");
    let indice = 0;
    while (indice < filtradas.length) {
        let op = filtradas[indice];
        console.log(
            op.tipo.toUpperCase() + ": " +
            op.numero1 + " y " + op.numero2 +
            " = " + op.resultado
        );
        indice++;
    }

    if (filtradas.length === 0) {
        console.log("Ninguna operación cumple el filtro.");
        alert("Ninguna operación cumple el filtro.");
    } else {
        alert("Las operaciones filtradas se muestran en la consola.");
    }
}

// LECCIÓN 5: Objeto con métodos, map y forEach
const CalculadoraABP = {
    nombre: "Calculadora ABP Consola",
    version: "1.0",
    mostrarResumen() {
        console.log("=== RESUMEN OBJETO CALCULADORA ===");
        console.log("Nombre:", this.nombre);
        console.log("Versión:", this.version);
        console.log("Cantidad de operaciones:", historialOperaciones.length);
    },
    mostrarHistorialAvanzado() {
        if (historialOperaciones.length === 0) {
            alert("No hay historial avanzado para mostrar.");
            return;
        }

        console.log("=== HISTORIAL AVANZADO (map + forEach) ===");

        // map: crear nuevo arreglo con info extra
        let historialConExtras = historialOperaciones.map(function (op) {
            return {
                ...op,
                dobleResultado: op.resultado * 2,
                esPositivo: op.resultado >= 0 ? "Sí" : "No"
            };
        });

        // forEach: recorrer y mostrar
        historialConExtras.forEach(function (op, indice) {
            console.log(
                (indice + 1) + ". " + op.tipo +
                " = " + op.resultado +
                " | doble: " + op.dobleResultado +
                " | ¿positivo?: " + op.esPositivo
            );
        });

        alert("Historial avanzado mostrado en consola.");
    }
};

// MENÚ PRINCIPAL (while + switch, usa todas las funciones)
function menuPrincipal() {
    let opcion;

    do {
        opcion = prompt(
            "=== MENÚ CALCULADORA ABP ===\n" +
            "1. Sumar\n" +
            "2. Restar\n" +
            "3. Multiplicar\n" +
            "4. Dividir\n" +
            "5. Ver historial completo (for)\n" +
            "6. Filtrar historial por resultado mínimo (while)\n" +
            "7. Ver historial avanzado (objetos + map/forEach)\n" +
            "0. Salir\n\n" +
            "Ingresa una opción:"
        );

        switch (opcion) {
            case "1":
                ejecutarOperacion("suma");
                break;
            case "2":
                ejecutarOperacion("resta");
                break;
            case "3":
                ejecutarOperacion("multiplicacion");
                break;
            case "4":
                ejecutarOperacion("division");
                break;
            case "5":
                mostrarHistorial();
                break;
            case "6":
                filtrarHistorialPorResultadoMinimo();
                break;
            case "7":
                CalculadoraABP.mostrarResumen();
                CalculadoraABP.mostrarHistorialAvanzado();
                break;
            case "0":
                alert("Gracias por usar la calculadora ABP, " + nombreUsuario + ".");
                console.log("Aplicación finalizada.");
                break;
            default:
                alert("Opción no válida. Intenta nuevamente.");
        }

    } while (opcion !== "0");
}

// INICIO DE LA APLICACIÓN
menuPrincipal();


